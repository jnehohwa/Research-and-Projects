# AI Use Disclosure Log

This log records AI assistance accurately. Before submission, it must be checked
against the official Eduvos disclosure template and AI-use rules.

| Date | Component | Prompt / request | Assistance received | Student verification and changes |
|---|---|---|---|---|
| 2026-08-26 | Assignment planning | "Go through that whole file and lets plan whats required for me to attain a high grade" | The rubric was summarised and converted into a deliverable-by-deliverable implementation plan. | Review the plan, choose the final architecture, and verify it against the LMS brief. |
| 2026-08-26 | Project setup | "This is due Friday btw, also can you work on the code part in VS code" | A maintainable Python package skeleton, development configuration, and initial disclosure log were created. | Open the project in VS Code, run the setup commands, and review every file before continuing. |
| 2026-08-26 | AI-use boundaries | "I checked it, we can use AI in this but it must not be obvious and i should just upload a file saying where i used ai and what prompts" | The assistant declined to conceal AI involvement and proposed an accurate disclosure and verification workflow. | Confirm the final disclosure matches the official LMS requirements. |
| 2026-08-26 | Full implementation plan | "Okay so whats the plan to finished everything to deliverable 5 and submit?" | A deadline-driven plan covering implementation, evidence, report writing and final packaging was produced. | Confirmed a report plus ZIP submission and static UI mockups. |
| 2026-08-26 | Implementation | "Implement the proposed plan." | AI assisted with the EduCore domain model, design patterns, concurrent registration service, Bugzot monitoring, automated tests, benchmarking, profiling evidence, UI mockups, architecture diagram, report structure and packaging. | Run all tests and demonstrations, inspect the report, understand the design decisions, correct any inaccuracies, and make the final submission personally. |

## Student verification declaration

Before submitting, I confirm that I have:

- reviewed every source file and can explain its role;
- run the automated tests and demonstration on my own machine;
- checked the screenshots, benchmark and profiling evidence against real output;
- reviewed the report and edited any wording that does not reflect my own understanding;
- disclosed AI assistance according to the Eduvos LMS requirements.

