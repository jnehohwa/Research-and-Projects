"""Automated tests for EduCore."""

